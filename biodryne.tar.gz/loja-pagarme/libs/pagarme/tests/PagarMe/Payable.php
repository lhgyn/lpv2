<?php

class PayableTest extends PagarMeTestCase
{
//    public static function getUrl() {
//        $class = get_called_class();
//        $search = preg_match("/PagarMe_(.*)/",$class, $matches);
//        return '/'. strtolower($matches[1]) . 's';
//    }

//    public static function testFindAllPayables()
//    {
//        authorizeFromEnv();
//        $payableModel = new PagarMe_Payable();
//        $payables = $payableModel::findAllByTransactionId(486987);
//    }

//    public static function testFindById()
//    {
//        authorizeFromEnv();
//        $payableModel = new PagarMe_Payable();
//        $payables = $payableModel::findTrasactionById(483148,24473);
//    }
}